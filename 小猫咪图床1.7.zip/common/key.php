<?php
$key="xiao520";
?>