<?php
include "../common/function.php";
echo update();